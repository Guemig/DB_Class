import { db } from './firebase_init.js';
import {
  collection,
  getDocs,
  getDoc,
  setDoc,
  doc,
  query,
  where,
  orderBy
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

export class FirestoreService {
  constructor(collectionName) {
    this.collectionName = collectionName;
    this.collectionRef = collection(db, collectionName);
  }

  async getAllDocuments() {
    const snapshot = await getDocs(this.collectionRef);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }

  async getDocumentById(id) {
    const docRef = doc(db, this.collectionName, id); // Corregido
    const snapshot = await getDoc(docRef);
    return snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null;
  }

  async PostDocument(customId, dataObject) {
    try {
      const docRef = doc(db, this.collectionName, customId.toString()); // Corregido
      await setDoc(docRef, dataObject);
      alert("Miembro registrado con éxito.");
    } catch (e) {
      console.error("Error al registrar el miembro:", e);
      alert("Error al registrar el miembro.");
    }
  }

  async getUsuariosPorNombreOrdenados(nombre) {
    try {
      const q = query(
        this.collectionRef,
        where("nombre", "==", nombre),
        orderBy("fechaRegistro", "desc") // Requiere índice compuesto
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (e) {
      console.error("Error en la consulta:", e);
      return [];
    }
  }
}

